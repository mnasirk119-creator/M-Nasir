# NK Gaming Booster APK project

This is a starter Android WebView wrapper for the NK Gaming Booster HTML prototype.
It creates an installable debug APK through GitHub Actions.

## Build without installing Android Studio on your laptop
1. Create a new GitHub repository in your browser.
2. Upload all files and folders from this project ZIP.
3. Open the repository's Actions tab.
4. Select "Build NK Gaming Booster APK" and click "Run workflow".
5. When it finishes, open the run and download the `NK-Gaming-Booster-APK` artifact.
6. Extract the downloaded artifact; `app-debug.apk` is the installable test APK.

Important: this first APK packages the dashboard UI only. The HTML recorder feature may not work inside Android WebView. A proper Android screen recorder needs native MediaProjection and audio-capture implementation, with Android's system permission prompt. This starter does not overclock the phone or force extra FPS.
